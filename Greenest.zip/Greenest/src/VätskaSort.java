public enum VätskaSort {
    KRANVATTEN, MINERALVATTEN, PROTEINDRYCK;
}
