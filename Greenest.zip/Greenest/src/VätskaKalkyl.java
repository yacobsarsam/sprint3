public interface VätskaKalkyl {
    double BeräknaVätska();
}